from oxforddictionaries.caching_language_dictionary import CachingLanguageDictionary
from oxforddictionaries.oxford_api_v2 import OxfordApiV2

if __name__ == "__main__":
    oxford_api = OxfordApiV2("73d55525", "d06c40c1779b65e8be19d20cd9d8001b")
    caching_language_dictionary = CachingLanguageDictionary(oxford_api, 'en-gb')
    #words = ["environmental sustainability", "equal employment","equal pay", "equality index", "esg factors", "esg goals", "esg governance", "esg initiatives", "esg issues", "esg matters", "esg performance", "esg reporting", "esg topics", "ethical business", "ethical conduct", "ethical standards", "europe middle", "european union", "executive compensation", "executive leadership", "executive level", "executive management", "executive officer"]
    file1 = open('words.txt', 'r')
    Lines = file1.readlines()
    for line in Lines:
        result = caching_language_dictionary.get_definitions(line.strip())
        print("Word is ", line.strip(), "Meaning is ", result)


